Dim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak MessageDim Message, Speak
          Message=InputBox("Enter a script Here And Run it!","Wyvern")
          Set Speak=CreateObject("sapi.spvoice")
          Speak.Speak Message